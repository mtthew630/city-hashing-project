package hash341;

public class City {
    public String name;
    public float latitude;
    public float longitude;

    public int getCollidedSpot() {
        return collidedSpot;
    }

    public void setCollidedSpot(int collidedSpot) {
        this.collidedSpot = collidedSpot;
    }

    public int collidedSpot;
}
